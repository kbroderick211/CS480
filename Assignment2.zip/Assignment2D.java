
public class Assignment2D {

	int main()
	{
	int i;
	for(i=1;i<=10;i++)
	print int("%d, %d, %d, %d",i,i*10,i*100,i*1000);

	}
}
